using System;
using System.Collections.Generic;
using System.Linq;

public class Band
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int YearFormed { get; set; }
    public string Country { get; set; }
    public int ChartPosition { get; set; }
    public List<int> SongIds { get; set; } = new List<int>();

    public override string ToString()
    {
        return $"{Id}|{Name}|{YearFormed}|{Country}|{ChartPosition}|{string.Join(",", SongIds)}";
    }

    public static Band FromString(string line)
    {
        var parts = line.Split('|');
        return new Band
        {
            Id = int.Parse(parts[0]),
            Name = parts[1],
            YearFormed = int.Parse(parts[2]),
            Country = parts[3],
            ChartPosition = int.Parse(parts[4]),
            SongIds = parts[5].Split(',').Where(s => !string.IsNullOrWhiteSpace(s)).Select(int.Parse).ToList()
        };
    }
}