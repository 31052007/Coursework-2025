using System;

public class Tour
{
    public int Id { get; set; }
    public string BandName { get; set; }
    public string City { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public double TicketPrice { get; set; }

    public TimeSpan Duration => EndDate - StartDate;

    public override string ToString()
    {
        return $"{Id}|{BandName}|{City}|{StartDate:yyyy-MM-dd}|{EndDate:yyyy-MM-dd}|{TicketPrice}";
    }

    public static Tour FromString(string line)
    {
        var parts = line.Split('|');
        return new Tour
        {
            Id = int.Parse(parts[0]),
            BandName = parts[1],
            City = parts[2],
            StartDate = DateTime.Parse(parts[3]),
            EndDate = DateTime.Parse(parts[4]),
            TicketPrice = double.Parse(parts[5])
        };
    }
}