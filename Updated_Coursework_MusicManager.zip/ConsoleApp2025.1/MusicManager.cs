using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public static class MusicManager
{
    public static List<Band> Bands { get; private set; } = new List<Band>();
    public static List<Song> Songs { get; private set; } = new List<Song>();
    public static List<Tour> Tours { get; private set; } = new List<Tour>();

    private const string BandsFile = "bands.txt";
    private const string SongsFile = "songs.txt";
    private const string ToursFile = "tours.txt";

    public static void LoadData()
    {
        if (File.Exists(BandsFile))
            Bands = File.ReadAllLines(BandsFile).Select(Band.FromString).ToList();

        if (File.Exists(SongsFile))
            Songs = File.ReadAllLines(SongsFile).Select(Song.FromString).ToList();

        if (File.Exists(ToursFile))
            Tours = File.ReadAllLines(ToursFile).Select(Tour.FromString).ToList();
    }

    public static void SaveData()
    {
        File.WriteAllLines(BandsFile, Bands.Select(b => b.ToString()));
        File.WriteAllLines(SongsFile, Songs.Select(s => s.ToString()));
        File.WriteAllLines(ToursFile, Tours.Select(t => t.ToString()));
    }

    public static void AddSongToBand(int bandId, Song song)
    {
        song.Id = Songs.Count > 0 ? Songs.Max(s => s.Id) + 1 : 1;
        Songs.Add(song);

        var band = Bands.FirstOrDefault(b => b.Id == bandId);
        band?.SongIds.Add(song.Id);

        SaveData();
    }

    public static void RemoveSongFromBand(int bandId, int songId)
    {
        var band = Bands.FirstOrDefault(b => b.Id == bandId);
        if (band != null && band.SongIds.Contains(songId))
        {
            band.SongIds.Remove(songId);
            Songs.RemoveAll(s => s.Id == songId);
            SaveData();
        }
    }

    public static IEnumerable<Song> GetSongsFromBandTours(string bandName)
    {
        var band = Bands.FirstOrDefault(b => b.Name == bandName);
        if (band == null) return Enumerable.Empty<Song>();
        return Songs.Where(s => band.SongIds.Contains(s.Id));
    }

    public static IEnumerable<Band> GetBandsByComposer(string composer)
    {
        var songIds = Songs.Where(s => s.Composer == composer).Select(s => s.Id);
        return Bands.Where(b => b.SongIds.Any(id => songIds.Contains(id)));
    }

    public static (Song, List<Band>) GetSongInfo(string title)
    {
        var song = Songs.FirstOrDefault(s => s.Title == title);
        var bands = Bands.Where(b => song != null && b.SongIds.Contains(song.Id)).ToList();
        return (song, bands);
    }

    public static IEnumerable<Song> GetMostPopularBandSongs()
    {
        var band = Bands.OrderBy(b => b.ChartPosition).FirstOrDefault();
        if (band == null) return Enumerable.Empty<Song>();
        return Songs.Where(s => band.SongIds.Contains(s.Id));
    }

    public static IEnumerable<string> GetTourDetails(string bandName)
    {
        return Tours
            .Where(t => t.BandName == bandName)
            .Select(t => $"{t.City}: {t.StartDate:dd.MM} - {t.EndDate:dd.MM}, {t.Duration.TotalDays} дней");
    }

    public static IEnumerable<Song> GetSongsByPerformer(string performer)
    {
        return Songs.Where(s => s.Performer == performer);
    }
}