using System;

public class Song
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Composer { get; set; }
    public string Lyricist { get; set; }
    public int Year { get; set; }
    public string Performer { get; set; }

    public override string ToString()
    {
        return $"{Id}|{Title}|{Composer}|{Lyricist}|{Year}|{Performer}";
    }

    public static Song FromString(string line)
    {
        var parts = line.Split('|');
        return new Song
        {
            Id = int.Parse(parts[0]),
            Title = parts[1],
            Composer = parts[2],
            Lyricist = parts[3],
            Year = int.Parse(parts[4]),
            Performer = parts[5]
        };
    }
}